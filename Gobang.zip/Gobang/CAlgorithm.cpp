#include "CAlgorithm.h"

// construction function for class CAlgorithm
CAlgorithm::CAlgorithm(string name):CGamePlayer(name)
{
	for(int i = 0; i < SIZE; i++)
	{
		for(int j = 0; j < SIZE; j++)
		{
			ownScoreTable[i][j] = 0;
			opponentScoreTable[i][j] = 0;
		}
	}
}


// function for clearing score tables
void CAlgorithm::cleanScoreTable()
{
	for(int i = 0; i < SIZE; i++)
	{
		for(int j = 0; j < SIZE; j++)
		{
			ownScoreTable[i][j] = 0;
			opponentScoreTable[i][j] = 0;
		}
	}
}

// find the max of the scoreTable
// 0: scan the own score table
// 1: scan the opponent score table
int CAlgorithm::findMaxScore(int which)
{
	int max = 0;
	for(int i = 0; i < SIZE; i++)
	{
		for(int j = 0; j < SIZE; j++)
		{
			if(0 == which)
			{
				if(max < ownScoreTable[i][j])
					max = ownScoreTable[i][j];
			}
			else if(1 == which)
			{
				if(max < opponentScoreTable[i][j])
					max = opponentScoreTable[i][j];
			}
		}
	}

	return max;
}

// function for algorithm palyer to compute a piece position
CPoint CAlgorithm::computePiecePosition(const CChessBoard &currentChessBoard, int stepNum)
{

	/************************************************************************/
	/**************************Score Scheme**********************************/
/*	
	// black side
		DEAD(1)	LIVE(2)	DUAL(3)		VAIN(4)	FIVE(5)	LONG(6)
	1	1		5					0
	2	10		50					0
	3	1000	10000				0
	4	5000	50000	-1000000	0
	5										1000000
	L												-1000000
	
	// white side
		DEAD(1)	LIVE(2)	DUAL(3)		VAIN(4)	FIVE(5)	LONG(6)
	1	1		5					0
	2	10		50					0
	3	1000	10000				0
	4	5000	50000	1000000		0
	5										1000000
	L												1000000
*/
	/************************************************************************/

	int i, j, k;
	int number, model;  // represent the chess model
	int blackScoreScheme[6][6];
	int whiteScoreScheme[6][6];
	// initialize the score scheme table
	for(i = 0; i < 6; i++)
	{
		for(j = 0; j < 6; j++)
		{
			blackScoreScheme[i][j] = 0;
			whiteScoreScheme[i][j] = 0;
		}
	}
	blackScoreScheme[0][DEAD-1] = 1; 
	blackScoreScheme[1][DEAD-1] = 10; 
	blackScoreScheme[2][DEAD-1] = 1000; 
	blackScoreScheme[3][DEAD-1] = 5000; 
	blackScoreScheme[0][LIVE-1] = 5; 
	blackScoreScheme[1][LIVE-1] = 50; 
	blackScoreScheme[2][LIVE-1] = 10000; 
	blackScoreScheme[3][LIVE-1] = 50000; 
	blackScoreScheme[3][DUAL-1] = -1000000; 
	blackScoreScheme[4][FIVE-1] = 1000000; 
	blackScoreScheme[5][LONG-1] = -1000000; 

	whiteScoreScheme[0][DEAD-1] = 1; 
	whiteScoreScheme[1][DEAD-1] = 10; 
	whiteScoreScheme[2][DEAD-1] = 1000; 
	whiteScoreScheme[3][DEAD-1] = 5000; 
	whiteScoreScheme[0][LIVE-1] = 5; 
	whiteScoreScheme[1][LIVE-1] = 50; 
	whiteScoreScheme[2][LIVE-1] = 10000; 
	whiteScoreScheme[3][LIVE-1] = 50000; 
	whiteScoreScheme[3][DUAL-1] = 1000000; 
	whiteScoreScheme[4][FIVE-1] = 1000000; 
	whiteScoreScheme[5][LONG-1] = 1000000; 


	// clear score tables for use
	this -> cleanScoreTable();

	CPoint bestPoint;
	CPoint imaginaryPoint;
	CPiece imaginaryPiece;
	CJudger imaginaryJudger;
	CChessBoard copiedChessBoard;
	// creat a imaginary opponent player object
	CGamePlayer opponentPlayer("opponentPlayer");
	if(BLACK == this->getColor())
		opponentPlayer.setColor(WHITE);
	else 
		opponentPlayer.setColor(BLACK);
		


	// i represents row
	for(i = 0; i < SIZE; i++)
	{
		// j represents columns
		for(j = 0; j < SIZE; j++)
		{
			// !!!
			// must remember the real coordinates are different from the index of array
			imaginaryPoint.x = j + 1;
			imaginaryPoint.y = i + 1;
			// the point must be blank
			if(NONE != copiedChessBoard.getValueAt(imaginaryPoint))
			{
				continue;
			}

			// store score of current point
			int currentScore = 0;

			/****************************** compute own score table************************************/
			imaginaryPiece = this->placePiece(imaginaryPoint);
			copiedChessBoard = currentChessBoard;
			copiedChessBoard.setValue(imaginaryPiece);
            imaginaryJudger.judgeChessModel(copiedChessBoard, imaginaryPiece);
			//int liveThreeNum = imaginaryJudger.judgeLiveThreeNum();
			//int liveFourNum = imaginaryJudger.judgeLiveFourNum();
			//int deadFourNum = imaginaryJudger.judgeDeadFourNum();

			for(k = 0; k < 4; k++)
			{
				number = imaginaryJudger.getChessModelValue(k, 0);
				model = imaginaryJudger.getChessModelValue(k, 1);
				// LONG chess model
				if(number > 5)
					number = 6;
				
				currentScore +=  blackScoreScheme[number - 1][model - 1];
			}

			// additional score
			//if((liveThreeNum >=2) || (liveFourNum + deadFourNum >= 2))
			// dual live three, dual four, long chain
			if( imaginaryJudger.judgeForbidden() )
			{
				if(BLACK == this->getColor())
					currentScore += -1000000;
				else
					currentScore += 1000000;
			}

			// the final score
			ownScoreTable[i][j] = currentScore;
			/*****************************************************************************************/

			// great importance
			currentScore = 0;

			/****************************** compute opponet score table*******************************/
			imaginaryPiece = opponentPlayer.placePiece(imaginaryPoint);
			copiedChessBoard = currentChessBoard;
			copiedChessBoard.setValue(imaginaryPiece);
            imaginaryJudger.judgeChessModel(copiedChessBoard, imaginaryPiece);
			//liveThreeNum = imaginaryJudger.judgeLiveThreeNum();
			//liveFourNum = imaginaryJudger.judgeLiveFourNum();
			//deadFourNum = imaginaryJudger.judgeDeadFourNum();

			for(k = 0; k < 4; k++)
			{
				number = imaginaryJudger.getChessModelValue(k, 0);
				model = imaginaryJudger.getChessModelValue(k, 1);
				// LONG chess model
				if(number > 5)
					number = 6;
				
				currentScore +=  blackScoreScheme[number - 1][model - 1];
			}


			// additional score
			//if((liveThreeNum >=2) || (liveFourNum + deadFourNum >= 2))
			if( imaginaryJudger.judgeForbidden() )
			{
				if(BLACK == opponentPlayer.getColor())
					currentScore += -1000000;
				else
					currentScore += 1000000;
			}

			// the final score
			opponentScoreTable[i][j] = currentScore;
			/*****************************************************************************************/

		}  // end j iteration
	}  // end i iteration




	/****************************** compute the best point ***********************************/

	// fist step to go "h8" if go first 
	if(0 == stepNum)
	{
		bestPoint.x = 8;  // h
		bestPoint.y = 8;  // 8
	}
	else
	{
		int ownMaxScore = this->findMaxScore(0);
		int opponentMaxScore = this->findMaxScore(1);
		int ownMax = -INF;
		int opponentMin = INF;

		// 
		if(ownMaxScore >= opponentMaxScore)
		{
			for(i = 0; i < SIZE; i++)
			{
				for(j = 0; j < SIZE; j++)
				{
					if(ownMaxScore == ownScoreTable[i][j])
					{
						if(opponentMin > opponentScoreTable[i][j])
						{
							bestPoint.x = j + 1;  
							bestPoint.y = i + 1; 
							opponentMin = opponentScoreTable[i][j];
						}
					}
				}  
			}
		}

		else if(ownMaxScore < opponentMaxScore)
		{
			for(i = 0; i < SIZE; i++)
			{
				for(j = 0; j < SIZE; j++)
				{
					if(opponentMaxScore == opponentScoreTable[i][j])
					{
						if(ownMax < ownScoreTable[i][j])
						{
							bestPoint.x = j + 1;  
							bestPoint.y = i + 1; 
							opponentMin =ownScoreTable[i][j];
						}
					}
				}  
			}
		}
		
	}


	/*****************************************************************************************/

	return bestPoint;
}