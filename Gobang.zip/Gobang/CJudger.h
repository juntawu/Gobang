#ifndef CJUDGER_H
#define CJUDGER_H

#include "CChessBoard.h"
#include "CGamePlayer.h"

#define DEAD 1  // dead chess model
#define LIVE 2  // live chess model
#define DUAL 3  // dual four chess model
#define VAIN 4  // impossible to win chess model 
#define FIVE 5  // five chain chess model
#define LONG 6  // long chain chess model

class CJudger
{
	// ���ӼƲ����ܣ�

public:
	// construction function for class CJudger
	CJudger();
	// function to clean chessModel
	void cleanChessModel();
	// count total steps
	void countStepNum();
	// get chess model value
	int getChessModelValue(int, int);
	// get current step numbers
	int getStepNum();
	// function to decide whether player's piece is valid
	bool isPieceValid(CChessBoard, CPiece);
	// function to judge current situation
	void judgeChessModel(CChessBoard, CPiece);
	// function to judge whether BLACK side violates the forbidden rule
	bool judgeForbidden();
	// function to judge whether BLACK side have piece chain over five pieces
	bool judgeLongChain();
	// function to judge whether BLACK side have piece chain over five pieces
	int judgeLiveThreeNum();
	// function to judge the number of live four chess model
	int judgeLiveFourNum();
	// function to judge the number of almost four chess model
	int judgeDeadFourNum();
	// function to judge whether player have piece chain of five pieces
	bool judgeFiveChain();
	// function to judge whether player wins the game
	int isWin(CGamePlayer);

private:
	/* array to store chess model;
	 * first dimention denotes the direction;
	 * second dimention stores length of the piece chain, number, type;
	 * type: DEAD, LIVE, VAIN
	 */
	int chessModel[4][2];
	int stepNum;
};

#endif