#include "CJudger.h"
#include <stdlib.h>  // include function "__max"

#include<iostream>
using namespace std;

// construction function for class CJudger
CJudger::CJudger()
{
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 2; j++)
			chessModel[i][j] = 0;  // 0 denotes nothing
	}
	stepNum = 0;
}

// function to clean chessModel
void CJudger::cleanChessModel()
{
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 2; j++)
			chessModel[i][j] = 0;  // 0 denotes nothing
	}
}

// get chess model value
int CJudger::getChessModelValue(int i, int j)
{
	return chessModel[i][j];
}


// count total steps
void CJudger::countStepNum()
{
	stepNum ++;
}

// get current step numbers
int CJudger::getStepNum()
{
	return stepNum;
}

// function to decide whether player's piece is valid
bool CJudger::isPieceValid(CChessBoard currentChessBoard, CPiece currentPiece)
{
	CPoint currentPoint = currentPiece.getPoint();
	if(NONE == currentChessBoard.getValueAt(currentPoint))
		return true;
	else 
		return false;
}

// function to judge current situation
void CJudger::judgeChessModel(CChessBoard currentChessBoard, CPiece currentPiece)
{
	
	/* four direction: 

				  *	3   * 2   * 1
					*	*   * 
					  *	* *
				* * * *	* * * * * 0
					  *	* *
					*	*   *
				 *   	*     *

	*/

	this->cleanChessModel();
	
	// judge the piece chain of four direction, 
	for(int i = 0; i < 4; i++)
	{
		CPoint leftPoint = currentPiece.getPoint();
		CPoint rightPoint = currentPiece.getPoint();
		CPoint directionDelta;
		CPoint tempPoint;

		switch(i)
		{
		case 0:
			directionDelta.x = 1;
			break;
		case 1: 
			directionDelta.x = 1;
			directionDelta.y = 1;
			break;
		case 2:
			directionDelta.y = 1;
			break;
		case 3:
			directionDelta.x = -1;
			directionDelta.y = 1;
			break;
		}

		/***************** find the left piece of current piece chain *******************/
		while(1)
		{
			tempPoint = leftPoint;
			// if the color of left piece is tha same as the current piece
			// move to further left piece 
			tempPoint.x -= directionDelta.x;
			tempPoint.y -= directionDelta.y;
			
			// if the color of left piece is not the same as the current piece 
			// or serch is beyond the boudary of chess board
			if(currentChessBoard.getValueAt(tempPoint) != currentPiece.getColor() \
				|| (tempPoint.x < 1) || (tempPoint.x > SIZE) || (tempPoint.y < 1) || (tempPoint.y > SIZE) )
			{
				break;
			}
			leftPoint = tempPoint;
		} // end while
		// the leftmost piece of the piece chain


		/***************** find the right piece of current piece chain *******************/
		while(1)
		{
			tempPoint = rightPoint;
			// if the color of left piece is tha same as the current piece
			// move to further left piece 
			tempPoint.x += directionDelta.x;
			tempPoint.y += directionDelta.y;

			// if the color of left piece is not the same as the current piece 
			// or serch is beyond the boudary of chess board
			if(currentChessBoard.getValueAt(tempPoint) != currentPiece.getColor() \
				|| (tempPoint.x < 1) || (tempPoint.x > SIZE) || (tempPoint.y < 1) || (tempPoint.y > SIZE) )
			{
				break;
			}
			rightPoint = tempPoint;
		} // end while

		// length of piece chain in current direction
		int chainLength = __max( abs(rightPoint.x - leftPoint.x), abs(rightPoint.y - leftPoint.y) ) + 1;
		
		
		/******************************* find the gap ****************************************/
		int leftState[5] = {0, 0, 0, 0, 0};
		int rightState[5] = {0, 0, 0, 0, 0};
		for(int k = 0; k < 5; k++)
		{
			// move left point to further left
			leftPoint.x -= directionDelta.x;
			leftPoint.y -= directionDelta.y;
			
			// move right point to furthre right
			rightPoint.x += directionDelta.x;
			rightPoint.y += directionDelta.y;

			// within the chess board
			if( (leftPoint.x >= 1) && (leftPoint.x <= SIZE) && (leftPoint.y >= 1) && (leftPoint.y <= SIZE) )
			{
				if(currentChessBoard.getValueAt(leftPoint) == NONE)
				{
					leftState[k] = 1;
				}
				else if(currentChessBoard.getValueAt(leftPoint) == currentPiece.getColor())
				{
					leftState[k] = 2;
				}
				else
				{
					leftState[k] = 0;
				}
			}
			// beyond the chess board
			else
			{
				leftState[k] = 0;
			}


			if( (rightPoint.x >= 1) && (rightPoint.x <= SIZE) && (rightPoint.y >= 1) && (rightPoint.y <= SIZE) )
			{
				if(currentChessBoard.getValueAt(rightPoint) == NONE)
				{
					rightState[k] = 1;
				}
				else if(currentChessBoard.getValueAt(rightPoint) == currentPiece.getColor())
				{
					rightState[k] = 2;
				}
				else
				{
					rightState[k] = 0;
				}
			}
			// beyond the chess board
			else
			{
				rightState[k] = 0;
			}
		}  // end iteration k
		
		int gap = chainLength;  // initiate gap
		for(k = 0; k < 5; k++)
		{
			if(0 == leftState[k])
				break;
			gap++;
		}
		for(k = 0; k < 5; k++)
		{
			if(0 == rightState[k])
				break;
			gap++;
		}
		/*****************************************************************************************/
		

		/******************** long chain *********************/
		if(5 < chainLength)
		{
			chessModel[i][0] = chainLength;
			chessModel[i][1] = LONG;
			/*
			// debugging codes
			cout<< "there is long chain" << endl;
			system("pause");
			*/
		}
		/*****************************************************/


		/******************** five chain *********************/
		if(5 == chainLength)
		{
			chessModel[i][0] = chainLength;
			chessModel[i][1] = FIVE;
		}
		/*****************************************************/



		/********************************************* BLACK SIDE ******************************************************/
		/***************************************************************************************************************/

		if(BLACK == currentPiece.getColor())
		{
						/******************** four chain *********************/
			if(4 == chainLength)
			{
				chessModel[i][0] = chainLength;
				// VAIN 4: can not form five_chain
				if(gap < 5)
				{
					chessModel[i][1] = VAIN;
				}	
				// live four, can form five chain by adding a piece at any of two specific position
				// !-****-!
				else if( (2 != leftState[1]) && (1 == leftState[0]) && (1 == rightState[0])  && (2 != rightState[1]) )
				{			
					chessModel[i][1] = LIVE;
				}
				// dead four, can form five chain by adding a piece only at a specific position
				// !-**** �� ****-!
				else if( (2 != leftState[1]) && (1 == leftState[0]) )
				{
					chessModel[i][1] = DEAD;
				}
				else if( (1 == rightState[0])  && (2 != rightState[1]) )
				{
					chessModel[i][1] = DEAD;
				}
				else
				{	
					chessModel[i][1] = VAIN;
				}
				
			}
			/*****************************************************/


			/******************** three chain ********************/
			if(3 == chainLength)
			{
				// VAIN 3: can not form five_chain
				if(gap < 5)
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = VAIN;
				}		
				// dual four, !*-***-*!
				else if( (2 != leftState[2]) && (2 == leftState[1]) && (1 == leftState[0]) && (1 == rightState[0]) \
						&& (2 == rightState[1]) && (2 != rightState[2]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DUAL;
				}
				// dead four, !*-*** �� ***-*! (except for cases above)
				else if( (2 != leftState[2]) && (2 == leftState[1]) && (1 == leftState[0]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DEAD;
				}
				else if( (1 == rightState[0]) && (2 == rightState[1]) && (2 != rightState[2]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DEAD;
				}
				// live three: !--***-!, !-***--!
				else if( (2 != leftState[2]) && (1 == leftState[1]) && (1 == leftState[0]) \
						&& (1 == rightState[0]) && (2 != rightState[1])  )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				else if( (2 != leftState[1]) && (1 == leftState[0]) \
						&& (1 == rightState[0]) && (1 == rightState[1]) && (2 != rightState[2])  )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				// dead three, !--***# �� !--***-** �� #***--! �� **-***--!
				else if( (2 != leftState[2]) && (1 == leftState[1]) && (1 == leftState[0]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				else if( (1 == rightState[0]) && (1 == rightState[1]) && (2 != rightState[2]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				// the rest cases
				else
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = VAIN;
				}
				
			}  // end if for three chain
			/*****************************************************/



			/********************* two chain *********************/
			if(2 == chainLength)
			{
				// VAIN 2: can not form five_chain
				if(gap < 5)
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = VAIN;
				}
				
				// DUAL four: !**-**-**!
				else if( (2 != leftState[3]) && (2 == leftState[2]) && (2 == leftState[1]) && (1 == leftState[0]) 
					&& (1 == rightState[0]) && (2 == rightState[1]) && (2 == rightState[2]) && (2 != rightState[3]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][2] = DUAL;
				}
				// DEAD 4: **-**! �� !**-** 
				else if( (2 == leftState[2]) && (2 == leftState[1]) && (1 == leftState[0]) && (2 != rightState[0]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][2] = DEAD;
				}
				else if( (2 != leftState[0]) && (1 == rightState[0]) && (2 == rightState[1]) && (2 == rightState[2]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][2] = DEAD;
				}
				// LIVE 3: !-*-**-! �� !-**-*-!
				else if( (2 != leftState[3]) && (1 == leftState[2]) && (2 == leftState[1]) && (1 == leftState[0]) \
						&& (1 == rightState[0]) && (2 != rightState[1]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				else if( (2 != leftState[1]) && (1 == leftState[0]) && (1 == rightState[0]) && (2 == rightState[1]) \
						&& (1 == rightState[2]) && (2 != rightState[3]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				// dead three: *-** �� **-* (except for the cases above)
				else if( (2 == leftState[1]) && (1 == leftState[0]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				else if( (1 == rightState[0]) && (2 == rightState[1]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				// VAIN 2: ***-**-***
				else if( (1 == rightState[0]) && (2 == rightState[1]) && (2 == rightState[2]) && (2 == rightState[3]) 
						&& (2 == leftState[3]) && (2 == leftState[2]) && (2 == leftState[1]) && (1 == leftState[0]))
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = VAIN;
				}
				// LIVE 2: -**-  (wait for being improved)
				else if( (1 == leftState[0]) && (1 == rightState[0]) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = LIVE;
				}
				// DEAD 2: #**- �� -**#  (wait for being improved)
				else if( (0 == leftState[0]) && (1 == rightState[0]) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = DEAD;
				}
				else if( (1 == leftState[0]) && (0 == rightState[0]) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = DEAD;
				}
				// the rest cases
				else
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = VAIN;
				}
			
			} // end if for two chain
			/*****************************************************/


			/***************************************** one chain ***************************************************/
			if(1 == chainLength)
			{
				// VAIN 1: can not form five_chain
				if(gap < 5)
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = VAIN;
				}
				// VAIN 4: impossible!!!
				
				// DUAL 4: !***-*-***!
				else if( (leftState[4] != 2) && (leftState[3] == 2) && (leftState[2] == 2) && (leftState[1] == 2) \
						&& (leftState[0] == 1)  && (rightState[0] == 1) \
						&& (rightState[1] == 2) && (rightState[2] == 2) && (rightState[3] == 2) && (rightState[4] != 2) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DUAL;	
				}
				// DEAD 4: !***-*, *-***! (except for cases above)
				else if( (leftState[4] != 2) && (leftState[3] == 2) && (leftState[2] == 2) && (leftState[1] == 2) && (leftState[0] == 1) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DEAD;
				}
				else if( (rightState[0] == 1) && (rightState[1] == 2) && (rightState[2] == 2) && (rightState[3] == 2) \
						&& (rightState[4] != 2) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DEAD;
				}
				// LIVE 3: !-**-*-!, !-*-**-!
				else if( (leftState[4] != 2) && (leftState[3] == 1) && (leftState[2] == 2) && (leftState[1] == 2) \
						&& (leftState[0] == 1)  && (rightState[0] == 1) && (rightState[1] != 2) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				else if( (leftState[0] != 2) && (leftState[1] == 1) && (rightState[0] == 1) && (rightState[1] == 2) \
						&& (rightState[2] == 2)  && (rightState[3] == 1) && (rightState[4] != 2) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				// DEAD 3: !-**-*-*, !-**-*#, *-*-**-!, #*-**-!
				else if( (leftState[4] != 2) && (leftState[3] == 1) && (leftState[2] == 2) && (leftState[1] == 2) \
						&& (leftState[0] == 1)  && (rightState[0] == 1) && (rightState[1] == 2) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				else if( (leftState[4] != 2) && (leftState[3] == 1) && (leftState[2] == 2) && (leftState[1] == 2) \
						&& (leftState[0] == 1)  && (rightState[0] == 0) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				else if( (leftState[1] == 2) && (leftState[0] == 1) && (rightState[0] == 1) && (rightState[1] == 2)\
						&& (rightState[2] == 2)  && (rightState[3] == 1) && (rightState[4] != 2) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				else if( (leftState[0] == 0) && (rightState[0] == 1) && (rightState[1] == 2) \
						&& (rightState[2] == 2)  && (rightState[3] == 1) && (rightState[4] != 2) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				// DEAD 2: -*-*-  (wiat for being improved)
				else if( (leftState[2] == 1) && (leftState[1] == 2) && (leftState[0] == 1) && (rightState[0] == 1) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = DEAD;
				}
				else if( (leftState[0] == 1) && (rightState[0] == 1) && (rightState[1] == 2) && (rightState[2] == 1) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = DEAD;
				}
				// LIVE 1: -*-
				else if((leftState[0] == 1) && (rightState[0] == 1))
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = LIVE;
				}
				// DEAD 1: #*-, -*#
				else if((leftState[0] == 0) && (rightState[0] == 1))
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = DEAD;
				}
				else if((leftState[0] == 1) && (rightState[0] == 0))
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = DEAD;
				}
				// the rest cases
				else
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = VAIN;
				}
			}  // end if for one chain
			/**********************************************************************************************************/

		}  // end if for black side
		
		/****************************************** END BLACK SIDE *****************************************************/
		/***************************************************************************************************************/

	



		/********************************************* WHITE SIDE ******************************************************/
		/***************************************************************************************************************/
		// current side is white
		else
		{
			/******************** four chain *********************/
			if(4 == chainLength)
			{
				chessModel[i][0] = chainLength;
				// VAIN 4: can not form five_chain
				if(gap < 5)
				{
					chessModel[i][1] = VAIN;
				}	
				// live four, can form five chain by adding a piece at any of two specific position
				// -****-
				else if( (1 == leftState[0]) && (1 == rightState[0]) )
				{			
					chessModel[i][1] = LIVE;
				}
				// dead four, can form five chain by adding a piece only at a specific position
				// -**** �� ****-
				else if(1 == leftState[0])
				{
					chessModel[i][1] = DEAD;
				}
				else if(1 == rightState[0])
				{
					chessModel[i][1] = DEAD;
				}
				// the rest cases
				else
				{	
					chessModel[i][1] = VAIN;
				}				
			}
			/*****************************************************/


			/******************** three chain ********************/
			if(3 == chainLength)
			{
				// VAIN 3: can not form five_chain
				if(gap < 5)
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = VAIN;
				}		
				// dual four, *-***-*
				else if( (2 == leftState[1]) && (1 == leftState[0]) && (1 == rightState[0]) && (2 == rightState[1]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DUAL;
				}
				// dead four, *-*** �� ***-* (except for cases above)
				else if( (2 == leftState[1]) && (1 == leftState[0]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DEAD;
				}
				else if( (1 == rightState[0]) && (2 == rightState[1]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DEAD;
				}
				// live three: --***-, -***--
				else if( (1 == leftState[1]) && (1 == leftState[0]) && (1 == rightState[0]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				else if( (1 == leftState[0]) && (1 == rightState[0]) && (1 == rightState[1]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				// dead three, --***# �� #***-- �� #-***-#
				// except for cases above
				else if( (1 == leftState[1]) && (1 == leftState[0]) && (0 == rightState[0]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				else if( (0 == leftState[0]) && (1 == rightState[0]) && (1 == rightState[1]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				else if( (0 == leftState[1]) && (1 == leftState[0]) && (1 == rightState[0]) && (0 == rightState[1]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				// the rest cases
				else
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = VAIN;
				}
				
			}  // end if for three chain
			/*****************************************************/



			/********************* two chain *********************/
			if(2 == chainLength)
			{
				// VAIN 2: can not form five_chain
				if(gap < 5)
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = VAIN;
				}
				
				// DUAL four: **-**-**
				else if( (2 == leftState[2]) && (2 == leftState[1]) && (1 == leftState[0]) 
					&& (1 == rightState[0]) && (2 == rightState[1]) && (2 == rightState[2]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][2] = DUAL;
				}
				// DEAD 4: **-** �� **-** 
				else if( (2 == leftState[2]) && (2 == leftState[1]) && (1 == leftState[0]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][2] = DEAD;
				}
				else if( (1 == rightState[0]) && (2 == rightState[1]) && (2 == rightState[2]) )
				{
					chessModel[i][0] = 4;
					chessModel[i][2] = DEAD;
				}
				// LIVE 3: -*-**- �� -**-*-
				else if( (1 == leftState[2]) && (2 == leftState[1]) && (1 == leftState[0]) && (1 == rightState[0]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				else if( (1 == leftState[0]) && (1 == rightState[0]) && (2 == rightState[1]) && (1 == rightState[2]))
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				// dead three: *-** �� **-* (except for the cases above)
				else if( (2 == leftState[1]) && (1 == leftState[0]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				else if( (1 == rightState[0]) && (2 == rightState[1]) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				// LIVE 2: -**-  (wait for being improved)
				else if( (1 == leftState[0]) && (1 == rightState[0]) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = LIVE;
				}
				// DEAD 2: **- �� -**  (wait for being improved)
				else if( (1 == leftState[0]) || (1 == rightState[0]) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = DEAD;
				}
				// the rest cases
				else
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = VAIN;
				}
			
			} // end if for two chain
			/*****************************************************/


			/***************************************** one chain ***************************************************/
			if(1 == chainLength)
			{
				// VAIN 1: can not form five_chain
				if(gap < 5)
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = VAIN;
				}
				// VAIN 4: impossible!!!
				
				// DUAL 4: ***-*-***
				else if( (leftState[3] == 2) && (leftState[2] == 2) && (leftState[1] == 2) \
						&& (leftState[0] == 1)  && (rightState[0] == 1) \
						&& (rightState[1] == 2) && (rightState[2] == 2) && (rightState[3] == 2) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DUAL;	
				}
				// DEAD 4: ***-*, *-*** (except for cases above)
				else if( (leftState[3] == 2) && (leftState[2] == 2) && (leftState[1] == 2) && (leftState[0] == 1) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DEAD;
				}
				else if( (rightState[0] == 1) && (rightState[1] == 2) && (rightState[2] == 2) && (rightState[3] == 2) )
				{
					chessModel[i][0] = 4;
					chessModel[i][1] = DEAD;
				}
				// LIVE 3: -**-*-, -*-**-
				else if( (leftState[3] == 1) && (leftState[2] == 2) && (leftState[1] == 2) \
						&& (leftState[0] == 1)  && (rightState[0] == 1) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				else if( (leftState[1] == 1) && (rightState[0] == 1) && (rightState[1] == 2) \
						&& (rightState[2] == 2)  && (rightState[3] == 1) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = LIVE;
				}
				// DEAD 3: -**-*# �� #*-**-
				else if( (leftState[3] == 1) && (leftState[2] == 2) && (leftState[1] == 2) \
						&& (leftState[0] == 1)  && (rightState[0] == 0) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				else if( (leftState[0] == 0) && (rightState[0] == 1) && (rightState[1] == 2) \
						&& (rightState[2] == 2)  && (rightState[3] == 1) )
				{
					chessModel[i][0] = 3;
					chessModel[i][1] = DEAD;
				}
				// LIVE 2: -*-*-  (wiat for being improved)
				else if( (leftState[2] == 1) && (leftState[1] == 2) && (leftState[0] == 1) && (rightState[0] == 1) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = LIVE;
				}
				else if( (leftState[0] == 1) && (rightState[0] == 1) && (rightState[1] == 2) && (rightState[2] == 1) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = LIVE;
				}
				// DEAD 2: *-*  (wiat for being improved)
				else if( (leftState[1] == 2) && (leftState[0] == 1) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = DEAD;
				}
				else if( (rightState[0] == 1) && (rightState[1] == 2) )
				{
					chessModel[i][0] = 2;
					chessModel[i][1] = DEAD;
				}

				// LIVE 1: -*-
				else if((leftState[0] == 1) && (rightState[0] == 1))
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = LIVE;
				}
				// DEAD 1: #*-, -*#
				else if((leftState[0] == 0) && (rightState[0] == 1))
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = DEAD;
				}
				else if((leftState[0] == 1) && (rightState[0] == 0))
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = DEAD;
				}
				// the rest cases
				else
				{
					chessModel[i][0] = 1;
					chessModel[i][1] = VAIN;
				}
			}  // end if for one chain
			/**********************************************************************************************************/

		}  // end else for white side

		/****************************************** END WHITE SIDE *****************************************************/
		/***************************************************************************************************************/


	}  // end iteration i 
}

// function to judge whether BLACK side violates the forbidden rule
bool CJudger::judgeForbidden()
{
	bool isThereForbidden = false;
	// great problem for missing parenthsis of expression "isThereFiveChain = this -> judgeFiveChain";
	bool isThereFiveChain = this -> judgeFiveChain();
	bool isThereLongChain = this -> judgeLongChain();
	int liveThreeNum = this -> judgeLiveThreeNum();
	int liveFourNum = this -> judgeLiveFourNum();
	int deadFourNum = this -> judgeDeadFourNum();

/*  // debugging codes
	if(true == isThereLongChain)
	{
		// testing
		cout << "there is long chain in (judgeForbidden)" << endl;
		system("pause");
	}
	if(true == isThereFiveChain)
	{
		// testing
		cout << "there is five chain in (judgeForbidden)" << endl;
		system("pause");
	}
	else
	{
		// testing
		cout << "no five chain in (judgeForbidden)" << endl;
		system("pause");
	}
*/

	// is there five chain, fobidden is invalid
	if(false == isThereFiveChain)
	{
		if(true == isThereLongChain)
			isThereForbidden = true;
		else if(liveThreeNum >= 2)
			isThereForbidden = true;
		else if( (liveFourNum + deadFourNum) >= 2)
			isThereForbidden = true;
	}

	return isThereForbidden;
}


// function to judge whether BLACK side have piece chain over five pieces
bool CJudger::judgeLongChain()
{
	bool isThereLongChain = false;
	for(int i = 0; i < 4; i++)
	{
		if( LONG == chessModel[i][1])
		{
			isThereLongChain = true;
		/*	
			// debugging codes
			cout << "there is long chain in (judgeLongChain)" << endl;
			system("pause");
		*/
			break;
		}
	}

	return isThereLongChain;
}

// function to judge whether BLACK side have piece chain over five pieces
int CJudger::judgeLiveThreeNum()
{
	int liveThreeNum = 0;
	for(int i = 0; i < 4; i++)
	{
		if( (3 == chessModel[i][0]) && (LIVE == chessModel[i][1]) )
			liveThreeNum ++;
	}
	return liveThreeNum;
}

// function to judge the number of live four chess model
int CJudger::judgeLiveFourNum()
{
	int liveFourNum = 0;
	for(int i = 0; i < 4; i++)
	{
		if( (4 == chessModel[i][0]) && (LIVE == chessModel[i][1]) )
			liveFourNum ++;
		else if( (4 == chessModel[i][0]) && (DUAL == chessModel[i][1]) )
			liveFourNum += 2;
	}
	return liveFourNum;;
}

// function to judge the number of almost four chess model
int CJudger::judgeDeadFourNum()
{
	int deadFourNum = 0;
	for(int i = 0; i < 4; i++)
	{
		if( (4 == chessModel[i][0]) && (DEAD == chessModel[i][1]) )
			deadFourNum ++;
	}
	return deadFourNum;
}

// function to judge whether player have piece chain of five pieces
bool CJudger::judgeFiveChain()
{
	bool isThereFiveChain = false;
	for(int i = 0; i < 4; i++)
	{
		if(FIVE == chessModel[i][1])
		{
			isThereFiveChain = true;
			break;
		}
	}
	return isThereFiveChain;
}

// function to judge whether player wins the game
int CJudger::isWin(CGamePlayer player)
{
	int winOrLose = 0; 
	bool isThereForbidden = this -> judgeForbidden();
	bool isThereFiveChain = this -> judgeFiveChain();
	bool isThereLongChain = this -> judgeLongChain();

	int currentColor = player.getColor();
/*  // debugging codes
	if(1 == isThereForbidden)
	{
		// testing
		cout << "current color is " << currentColor << endl;
		cout << "there is forbidden in (isWin)" << endl;
		system("pause");
	}
*/
	// black side can only win by five chain, lose by forbidden
	if(BLACK == currentColor)
	{
		if(isThereForbidden)
			winOrLose = -1;
		else if(isThereFiveChain)
			winOrLose = 1;
		else 
			winOrLose = 0;
	}
	// white side can win by five chain or long chain
	else
	{
		if(isThereFiveChain || isThereLongChain)
			winOrLose = 1;
		else 
			winOrLose = 0;
	}
		
	return winOrLose;	
}
