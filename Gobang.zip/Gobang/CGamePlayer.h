#ifndef CGAMEPLAYER_H
#define CGAMEPLAYER_H

#include <string>
#include "CPiece.h"
using namespace std;  // string needs this!!!

// class for player
class CGamePlayer
{
public:	
	CGamePlayer(string);
	string getName();
	void setName(string);
	int getColor();
	void setColor(int);
	CPiece placePiece(CPoint);

private:
	string name;
	int color;
};


#endif