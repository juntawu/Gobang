#include "CGamePlayer.h"

// construction function for class CPlayer
CGamePlayer::CGamePlayer(string name)
{
	(this -> name) = name;
	color = NONE;
}

// functiong to get player's name
string CGamePlayer::getName()
{
	return (this -> name);
}

// functiong to set player's name
void CGamePlayer::setName(string name)
{
	(this -> name) = name;
}

// function to get color representing the player
int CGamePlayer::getColor()
{
	return (this -> color);
}

// function to set color represengting the player
void CGamePlayer::setColor(int color)
{
	(this -> color) = color;
}

// function for player to place piece 
CPiece CGamePlayer::placePiece(CPoint point)
{	
	CPiece piece(this -> color);
	piece.setPoint(point);
	return piece;
}
