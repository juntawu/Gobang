#ifndef CCHESSBOARD_H
#define CCHESSBOARD_H

#include "CPiece.h"

#define SIZE 15

// class for chessBoard
class CChessBoard
{
public:
	CChessBoard();
	void setValue(CPiece);  // set a point according to the current piece
	int getValueAt(CPoint);  // get the value of the specific point
	void diplay();  // display blank chess board
	void diplay(CPoint);  // display current chess board with pieces

private:
	// each point of chess board has a value to denote its status
	// NONE for blank; BLACK for balck piece; WHITE for white piece
	int value[SIZE][SIZE];
};


#endif