#include "CPoint.h"

// construction function of class CPoint
CPoint::CPoint()
{
	x = 0;
	y = 0;
}

