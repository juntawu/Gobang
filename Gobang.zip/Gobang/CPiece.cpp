#include "CPiece.h"


// construction function for class CPiece
CPiece::CPiece()
{
	this -> color = NONE;
}

// construction function for class CPiece
CPiece::CPiece(int color)
{
	this -> color = color;
}


// member function to get piece's position
CPoint CPiece::getPoint()
{
	CPoint currentPoint;
	currentPoint.x = (this -> point).x;
	currentPoint.y = (this -> point).y;
	return currentPoint;
}

// member function to get piece's color
int CPiece::getColor()
{
	return (this -> color); 
}

// member function to set piece's position
void CPiece::setPoint(CPoint givenPoint)
{
	(this -> point).x = givenPoint.x;
	(this -> point).y = givenPoint.y;
}

// member function to set piece's color
void CPiece::setColor(int givenColor)
{
	(this -> color) = givenColor;
}