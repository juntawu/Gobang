#ifndef CORGANIZER_H
#define CORGANIZER_H

#include<stdlib.h>  // clear screen

#include "CJudger.h"
#include "CGamePlayer.h"
#include "CChessBoard.h"
#include "CPiece.h"
#include "CPoint.h"
#include "CAlgorithm.h"

// game model
#define MM 0  // human vs human
#define AM 1  // human vs algorithm

class COrganizer
{
public:
	void runGame();
	string getString();
	int decideGameModel();
	int decideWhoGoFirst(int);
	CPoint decidePiecePosition(int);
	void displayCurrentChessBoard(CChessBoard, int);
	void displayCurrentChessBoard(CChessBoard, CPoint, int);
	bool decidePlayAgain();

};

#endif