#ifndef CPIECE_H
#define CPIECE_H

#include "CPoint.h"

#define NONE 0  // NONE for nothing
#define BLACK 1  // 1 for black piece
#define WHITE 2  // 2 for white piece

// class for piece
class CPiece
{
public:
	CPiece();
	CPiece(int);
	CPoint getPoint();
	int getColor();
	void setPoint(CPoint);
	void setColor(int);

private:
	//CPoint point();  // should use construction function of class CPoint 
	CPoint point;
	int color;

};

#endif