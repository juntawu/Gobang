#ifndef CALGORITHM_H
#define CALGORITHM_H

#include "CGamePlayer.h"
#include "CJudger.h"
#include "CPiece.h"
#include "CChessBoard.h"
#include "CPiece.h"
#include "CPoint.h"

// maxmium number of int type is 2^32
#define INF 1000000000

class CAlgorithm: public CGamePlayer
{
public:
	CAlgorithm(string name);
	void cleanScoreTable();
	int findMaxScore(int);
	CPoint computePiecePosition(const CChessBoard &, int);


private:
	int ownScoreTable[SIZE][SIZE];
	int opponentScoreTable[SIZE][SIZE];
};


#endif