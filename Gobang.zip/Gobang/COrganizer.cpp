#include "COrganizer.h"
#include <iostream>
using namespace std;

void COrganizer::runGame()
{
	while(1)
	{	
		// clear the screen at the begining
		system("cls");

		CGamePlayer player1("player1"), player2("player2");
		CJudger judger;
		CChessBoard chessBoard;
		// 0 note that it's player1's turn currently
		int whoseTurnFlag = 0;
		int gameModel = 0;
		gameModel = this -> decideGameModel();
		int whoGoFirst = 0;
		whoGoFirst = this -> decideWhoGoFirst(gameModel);

		/*********************** human-human model*************************/
		/******************************************************************/
		if(MM == gameModel)
		{
			// player1 go first
			if(0 == whoGoFirst)
			{
				player1.setColor(BLACK);
				player2.setColor(WHITE);
				whoseTurnFlag = 0;
			}
			// player2 go first
			else
			{
				player1.setColor(WHITE);
				player2.setColor(BLACK);
				whoseTurnFlag = 1;
			}
			
			// display the blank chess board
			this -> displayCurrentChessBoard(chessBoard, whoseTurnFlag);
			CPoint currentPoint;
			CPiece currentPiece;
			CGamePlayer currentPlayer("currentPlayer");
			int result = 0;
			while(1)
			{				
				currentPoint = this -> decidePiecePosition(whoseTurnFlag);
				if(0 == whoseTurnFlag)
					currentPlayer = player1;
				else
					currentPlayer = player2;
				
				currentPiece = currentPlayer.placePiece(currentPoint);
				if(!judger.isPieceValid(chessBoard, currentPiece))
				{	
					cout << "Invalid position!!!"  << endl;
					continue;
				}
				
				// chessBoard change the value
				chessBoard.setValue(currentPiece);
				// display current chess board
				this -> displayCurrentChessBoard(chessBoard, currentPoint, whoseTurnFlag);
				judger.judgeChessModel(chessBoard, currentPiece);
				result = judger.isWin(currentPlayer);
				if(0 == result)
				{
					if(0 == whoseTurnFlag)
						whoseTurnFlag = 1;
					else
						whoseTurnFlag = 0;

					continue;
				}
				else if(-1 == result)
				{
					cout << "current player lose!" << endl;
					break;
				}
				else if(1 == result)
				{
					cout << "current player win!" << endl;
					break;
				}
			}

		}
		/********************** end human-human model**********************/
		/******************************************************************/


		
		/********************** human-algorithm model**********************/
		/******************************************************************/
		else if(AM == gameModel)
		{
			CGamePlayer human("player1");
			CAlgorithm algorithm("player2");
			// player1 go first
			if(0 == whoGoFirst)
			{
				human.setColor(BLACK);
				algorithm.setColor(WHITE);
				whoseTurnFlag = 0;
			}
			// player2 go first
			else
			{
				human.setColor(WHITE);
				algorithm.setColor(BLACK);
				whoseTurnFlag = 1;
			}
			
			// display the blank chess board
			this -> displayCurrentChessBoard(chessBoard, whoseTurnFlag);
			CPoint currentPoint;
			CPiece currentPiece;
			//CGamePlayer currentPlayer("currentPlayer");
			int result = 0;
			while(1)
			{				
			
				if(0 == whoseTurnFlag)
				{
					currentPoint = this -> decidePiecePosition(whoseTurnFlag);
					currentPiece = human.placePiece(currentPoint);
				}
				else
				{	
					currentPoint = algorithm.computePiecePosition(chessBoard, judger.getStepNum());
					currentPiece = algorithm.placePiece(currentPoint);
				}
				
				if(!judger.isPieceValid(chessBoard, currentPiece))
				{	
					cout << "Invalid position!!!"  << endl;
					continue;
				}
				
				// chessBoard change the value
				chessBoard.setValue(currentPiece);
				// display current chess board
				this -> displayCurrentChessBoard(chessBoard, currentPoint, whoseTurnFlag);
				judger.judgeChessModel(chessBoard, currentPiece);
				// !!!
				// great importance
				judger.countStepNum();

				if(0 == whoseTurnFlag)
					result = judger.isWin(human);
				else
					result = judger.isWin(algorithm);
				
				if(0 == result)
				{
					if(0 == whoseTurnFlag)
						whoseTurnFlag = 1;
					else
						whoseTurnFlag = 0;

					continue;
				}
				else if(-1 == result)
				{
					cout << "        current player lose!" << endl;
					break;
				}
				else if(1 == result)
				{
					cout << "        current player win!" << endl;
					break; 
				}
			}  // end inner while

		}  // end else if for algorithm model
		/********************* end human-algorithm model*******************/
		/******************************************************************/

		if(this->decidePlayAgain())
			continue;
		else
			break;
	}  // end extra while

}


// function to get the string form the keyboard
string COrganizer::getString()
{
	string str;
	char inputCharacter;
	cin >> noskipws >> inputCharacter;
	while(inputCharacter != '\n')
	{
		str += inputCharacter;
		cin >> noskipws >> inputCharacter;		
	}

	return str;
}


// function for user to decide which game model to play
int COrganizer::decideGameModel()
{
	int gameModel = 0;
	string inputString;

	// notice information
	cout << "*********************************************" << endl;
	cout << endl << "         Welcome to Gobang Game!" << endl << endl;
	cout << "              Author: WJT" << endl;
	cout << "*********************************************" << endl << endl << endl;

	cout << "*********************************************" << endl;
	cout << "Please decide which game model to play!" << endl << endl;
	cout << "0: Human-Human; " << endl;
	cout << "1: Human-Algorithm; " << endl;
	cout << "*********************************************" << endl;
	cout << "Please input \"0\" or \"1\" (end with ENTER) >>> ";
	
	while(1)
	{
		inputString =  this->getString();
		if(1 == inputString.length())
		{
			if("0" == inputString)
			{
				gameModel = MM;
				break;
			}
			else if("1" == inputString)
			{
				gameModel = AM;
				break;
			}
			else
			{
				cout << "Oops!!! Wrong input, please input again!" << endl;
				cout << "Please input \"0\" or \"1\" (end with ENTER) >>> ";
			}
		}
		else
		{
			cout << "Oops!!! Wrong input, please input again!" << endl;
			cout << "Please input \"0\" or \"1\" (end with ENTER) >>> ";
		}
	}

	return gameModel;
}


// function for user to decide who go first
int COrganizer::decideWhoGoFirst(int gameModel)
{
	int whoGoFirst = 0;
	string inputString;

	if(MM == gameModel)
	{
		cout << endl << endl << endl;
		cout << "*********************************************" << endl;
		cout << "Please decide who go first!" << endl << endl;
		cout << "0: Player1; " << endl;
		cout << "1: Player2; " << endl;
		cout << "*********************************************" << endl;
		cout << "Please input \"0\" or \"1\" (end with ENTER) >>> ";
	}
	else if(AM == gameModel)
	{
		cout << endl << endl << endl;
		cout << "*********************************************" << endl;
		cout << "Please decide who go first!" << endl << endl;
		cout << "0: Human; " << endl;
		cout << "1: Algorithm; " << endl;
		cout << "*********************************************" << endl;
		cout << "Please input \"0\" or \"1\" (end with ENTER) >>> ";
	}

	while(1)
	{
		inputString =  this->getString();
		if(1 == inputString.length())
		{
			if("0" == inputString)
			{
				whoGoFirst = 0;
				cout << "Player1 or Human go first" << endl;
				break;
			}
			else if("1" == inputString)
			{
				whoGoFirst = 1;
				cout << "Player2 or AI go first" << endl;
				break;
			}
			else
			{
				cout << "Oops!!! Wrong input, please input again!" << endl;
				cout << "Please input \"0\" or \"1\" (end with ENTER) >>> ";
			}
		}
		else
		{
			cout << "Oops!!! Wrong input, please input again!" << endl;
			cout << "Please input \"0\" or \"1\" (end with ENTER) >>> ";
		}
	}

	return whoGoFirst;
}

// function for user to decide which point to go
CPoint COrganizer::decidePiecePosition(int whoseTurnFlag)
{
	CPoint piecePosition;
	string inputString;
	int inputX, inputY;
	
	cout << endl;
	cout << "*********************************************" << endl;
	cout << "Please choose a point <x, y> to put a piece!" << endl;
	cout << "x: a - o; " << endl;
	cout << "y: 1 - 15; " << endl;
	cout << "*********************************************" << endl;
	if(0 == whoseTurnFlag)
		cout << "Player1 input a point <x, y>, for example, \"h8\" >>> ";
	else if(1 == whoseTurnFlag)
		cout << "Player2 input a point <x, y>, for example, \"h8\" >>> ";

	while(1)
	{
		inputString =  this->getString();
		inputX = 0;
		inputY = 0;

		if( (2 == inputString.length()) || (3 == inputString.length()) )
		{
			// first character is 'a'-'o' or 'A'-'O'
			if( ('a' <= inputString[0] && 'o' >= inputString[0]) || ('A' <= inputString[0] && 'O' >= inputString[0] ) )
			{
				// first character
				if('a' <= inputString[0] && 'o' >= inputString[0])
					inputX = inputString[0] - 'a' + 1;
				else if(('A' <= inputString[0] && 'O' >= inputString[0] ))
					inputX = inputString[0] - 'A' + 1;

				// 2-3 character is number 1-15
				if(2 == inputString.length())
					inputY = inputString[1] - '0';
				else if(3 == inputString.length())
					inputY = (inputString[1] - '0') * 10 + (inputString[2] - '0');

				if(1 <= inputY && 15>= inputY)
					break;
				else
				{
					cout << "Oops!!! Wrong input, please input again!" << endl;
					if(0 == whoseTurnFlag)
						cout << "Player1 input a point <x, y>, for example, \"h8\" >>> ";
					else if(1 == whoseTurnFlag)
						cout << "Player2 input a point <x, y>, for example, \"h8\" >>> ";
				}
			}
			else
			{
				cout << "Oops!!! Wrong input, please input again!" << endl;
				if(0 == whoseTurnFlag)
					cout << "Player1 input a point <x, y>, for example, \"h8\" >>> ";
				else if(1 == whoseTurnFlag)
					cout << "Player2 input a point <x, y>, for example, \"h8\" >>> ";
			}
		}
		else
		{
			cout << "Oops!!! Wrong input, please input again!" << endl;
			if(0 == whoseTurnFlag)
				cout << "Player1 input a point <x, y>, for example, \"h8\" >>> ";
			else if(1 == whoseTurnFlag)
				cout << "Player2 input a point <x, y>, for example, \"h8\" >>> ";
		}
	}

	piecePosition.x = inputX;
	piecePosition.y = inputY;
	return piecePosition;
}


void COrganizer::displayCurrentChessBoard(CChessBoard currentChessBoard, int whoseTurnFlag)
{
	// library: <stdlib.h>
	// refresh the screen
	system("cls");
	currentChessBoard.diplay();
	//this -> decidePiecePosition(whoseTurnFlag);
}

void COrganizer::displayCurrentChessBoard(CChessBoard currentChessBoard, CPoint currentPoint, int whoseTurnFlag)
{
	// library: <stdlib.h>
	// refresh the screen
	system("cls");
	currentChessBoard.diplay(currentPoint);
	//this -> decidePiecePosition(whoseTurnFlag);
}


bool COrganizer::decidePlayAgain()
{
	bool playAgain = false;
	string inputString;

	cout << endl;
	cout << "*********************************************" << endl;
	cout << "Do you want to play again ?" << endl << endl;
	cout << "y or Y for yes;  n or N for no" << endl;
	cout << "*********************************************" << endl;
	cout << "Please input \"y\" or \"n\" (end with ENTER) >>> ";
	while(1)
	{
		inputString =  this->getString();
		if(1 == inputString.length())
		{
			if("y" == inputString || "Y" == inputString)
			{
				playAgain = true;
				break;
			}
			else if("n" == inputString || "N" == inputString)
			{
				playAgain = false;
				break;
			}
			else
			{
				cout << "Oops!!! Wrong input, please input again!" << endl;
				cout << "Please input \"y\" or \"n\" (end with ENTER) >>> ";
			}
		}
		else
		{
			cout << "Oops!!! Wrong input, please input again!" << endl;
			cout << "Please input \"y\" or \"n\" (end with ENTER) >>> ";
		}
	}

	return playAgain;
}