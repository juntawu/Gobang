#include "CChessBoard.h"
#include <iostream>
using namespace std;

// construction function for class CChesSBoard
CChessBoard::CChessBoard()
{
	for(int i = 0; i < SIZE; i++)
	{
		for(int j = 0; j < SIZE; j++)
		{
			// chess board is blank for initialization
			value[i][j] = NONE;
		}
	}
}

// set a point of chess board according to the current piece 
void CChessBoard::setValue(CPiece currentPiece)
{
	CPoint currentPoint = currentPiece.getPoint();
	// be careful the index!!!
	value[currentPoint.y - 1][currentPoint.x - 1] = currentPiece.getColor();
}

// get the value of the specific point
int CChessBoard::getValueAt(CPoint point)
{
	return value[point.y - 1][point.x - 1];
}

// display blank chess board 
void CChessBoard::diplay()
{
	int i=0, j=0;

	//mark the column
	cout << "    ";
	for(j = 0; j < SIZE; j++){
		cout << (unsigned char)('a' + j) << ' ';
	}
	cout << endl;

	for(i = 0; i < SIZE; i++)
	{
		// mark the row
		if((i + 1) < 10)
			cout << "  " << i + 1 << " ";  
		else 
			cout << " " << i + 1 << " ";

		for(j = 0; j < SIZE; j++)
		{
			/***************** display the first row of the chess board *******************/
			if(0 == i)
			{
				// the left top corner of the chess board
				if(0 == j)
					cout << "��";
				// the right top corner of the chess board
				else if((SIZE - 1) == j)
					cout << "��";
				// top line of the chess board
				else 
					cout << "��";
			}

			
			/************* display the 2-th to 14-th row of the chess board ***************/
			if(i > 0 && i < SIZE - 1)
			{
				// left line of the chess board
				if(0 == j)
					cout << "��";
				// right line of the chess board
				else if((SIZE - 1) == j)
					cout << "��";
				// the cross of the chess board
				else 
					cout << "��";

			}


			/***************** display the last row of the chess board ********************/
			if((SIZE - 1) == i)
			{
				// the left bottom corner of the chess board
				if(0 == j)
					cout << "��";
				// the right bottom corner of the chess board
				else if((SIZE - 1) == j)
					cout << "��";
				// bottom line of the chess board
				else 
					cout << "��";
			}
		}
		
		// the end of each row needs a new line character
		cout << endl;
	}
	
	
/*
	// mark the row and display the chessBoard
	for(i = 0; i <= 14; i++ ){
		//cout << "  " << (i + 1) << " ";
		cout << " " << setw(2) << (i + 1) << " ";
		cout << endl;
	}
*/
	cout << endl;
	
}


// display current chess board with pieces
// with a mark for current piece
void CChessBoard::diplay(CPoint currentPoint)
{
	int i=0, j=0;
	
	//mark the column
	cout << "    ";
	for(j = 0; j < SIZE; j++){
		cout << (unsigned char)('a' + j) << ' ';
	}
	cout << endl;

	for(i = 0; i < SIZE; i++)
	{
		// mark the row
		if((i + 1) < 10)
			cout << "  " << i + 1 << " ";  
		else 
			cout << " " << i + 1 << " ";
		

		for(j = 0; j < SIZE; j++)
		{
			/***************************** mark the current piece *****************************/
			if((currentPoint.y - 1) == i && (currentPoint.x - 1) == j)
			{
				switch(value[i][j])
				{
					case BLACK:
					{
						cout << "��";
						break;
					}
					case WHITE:
					{
						cout << "��";
						break;
					}

					default:
						;
				}	
			} // end if for current piece

			/***********************************************/
			else
			{
				// blank point of chess board
				if(NONE == value[i][j])
				{
					/***************** display the first row of the chess board *******************/
					if(0 == i)
					{
						// the left top corner of the chess board
						if(0 == j)
							cout << "��";
						// the right top corner of the chess board
						else if((SIZE - 1) == j)
							cout << "��";
						// top line of the chess board
						else 
							cout << "��";
					}

					
					/************* display the 2-th to 14-th row of the chess board ***************/
					if(i > 0 && i < SIZE - 1)
					{
						// left line of the chess board
						if(0 == j)
							cout << "��";
						// right line of the chess board
						else if((SIZE - 1) == j)
							cout << "��";
						// the cross of the chess board
						else 
							cout << "��";

					}


					/***************** display the last row of the chess board ********************/
					if((SIZE - 1) == i)
					{
						// the left bottom corner of the chess board
						if(0 == j)
							cout << "��";
						// the right bottom corner of the chess board
						else if((SIZE - 1) == j)
							cout << "��";
						// bottom line of the chess board
						else 
							cout << "��";
					}

				} // end "if" for blank point

				// non-blank point of chess board
				else
				{
					switch(value[i][j])
					{
						case BLACK:
						{
							cout << "��";
							break;
						}
						case WHITE:
						{
							cout << "��";
							break;
						}

						default:
							;
					}
				} // end "else" for non-blank point

			} // end "else" for non current piece 

		} // end "j" iteration
		
		// the end of each row needs a new line character
		cout << endl;
	} // end "i" iteration


	cout << endl;
}