#ifndef CPOINT_H
#define CPOINT_H

//#include <iostream>
//using namespace std;

// class for positon on chess board
class CPoint
{
public:
	CPoint();
	int x;
	int y;
}; // don't forget the semicolon!!!

#endif
