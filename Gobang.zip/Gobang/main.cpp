#include <iostream>
#include "CChessBoard.h"
#include "CGamePlayer.h"
#include "COrganizer.h"
#include<stdlib.h>  // cls
#include<iostream>
using namespace std;

int main()
{

	COrganizer organizer;
	organizer.runGame();

/*	CChessBoard chessBoard;
	//chessBoard.diplay();

	system("cls");

	CPoint currentPoint;
	currentPoint.x = 8;
	currentPoint.y = 7;
	CPiece currentPiece(WHITE);
	currentPiece.setPoint(currentPoint);
	chessBoard.setValue(currentPiece);
	//chessBoard.diplay(currentPoint);

	COrganizer organizer;
	int gameModel = organizer.decideGameModel();
	organizer.decideWhoGoFirst(gameModel);
	organizer.displayCurrentChessBoard(chessBoard, currentPoint, 0);
	//CPoint piecePosition = organizer.decidePiecePosition();
	//cout << "<x, y>: " << piecePosition.x << ", " << piecePosition.y << endl;

	char inputChar;
	string str;
	str = organizer.getString();
	cout << str << endl;
	//cout << str.length() << endl;
	if(str == "12")
		cout << "That's right" << endl;

	cout << str[3] << endl;

	//cin >> inputChar;
	//cout << inputChar << endl;
*/	

	return 0;
}
